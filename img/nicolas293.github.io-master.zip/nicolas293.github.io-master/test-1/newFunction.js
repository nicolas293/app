function newFunction() {
  return td.style.display = "block";
}
